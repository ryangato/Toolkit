/***********************************************************************
tcping.exe -- A tcp probe utility
Copyright (C) 2005-2013 Eli Fulkerson

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

----------------------------------------------------------------------

Other license terms may be negotiable.  Contact the author if you would
like a copy that is licensed differently.

Contact information (as well as this program) lives at http://www.elifulkerson.com

----------------------------------------------------------------------

This application includes public domain code from the Winsock Programmer's FAQ:
  http://www.tangentsoft.net/wskfaq/
... and a big thank you to the maintainers and contributers therein.

***********************************************************************/

#pragma comment(lib, "Ws2_32.lib")

#include <winsock2.h>
#include <stdlib.h>
#include <iostream>
#include "tcping.h"

using namespace std;

void usage(int argc, char* argv[]) {
    cout << "--------------------------------------------------------------" << endl;
    cout << "tcping.exe by Eli Fulkerson " << endl;
    cout << "Please see http://www.elifulkerson.com/projects/ for updates. " << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << endl;
    cout << "Usage: " << argv[0] << " [-flags] server-address [server-port]" << endl << endl;
    cout << "Usage (full): " << argv[0] << " [-t] [-d] [-i interval] [-n times] [-w ms] [-b n] [-r times] [-s] [-v] [-j] [--tee filename] [-h] [-u] [--post] [--head] [-f] server-address " << "[server-port]" << endl << endl;
    cout << " -t     : ping continuously until stopped via control-c" << endl;
    cout << " -n 5   : for instance, send 5 pings" << endl;
    cout << " -i 5   : for instance, ping every 5 seconds" << endl;
    cout << " -w 0.5 : for instance, wait 0.5 seconds for a response" << endl;
    cout << " -d     : include date and time on each line" << endl;
    cout << " -b 1   : enable beeps (1 for on-down, 2 for on-up," << endl;
    cout << "                        3 for on-change, 4 for always)" << endl;
    cout << " -r 5   : for instance, relookup the hostname every 5 pings" << endl;
    cout << " -s     : automatically exit on a successful ping"<<endl;                  //[Modification 14 Apr 2011 by Michael Bray, mbray@presidio.com]
    cout << " -v     : print version and exit" << endl;
    cout << " -j [5] : include jitter.  Optional argument controls rolling average size." << endl;
    cout << " --tee  : mirror output to a filename specified after '--tee'" << endl;
	cout << " -4     : prefer ipv4" << endl;
	cout << " -6     : prefer ipv6" << endl;
	cout << " -c     : only show an output line on changed state" << endl;
    cout << endl << "HTTP Options:" << endl;
    cout << " -h     : HTTP mode (use url without http:// for server-address)" << endl;
    cout << " -u     : include target URL on each line" << endl;
    cout << " --post : use POST rather than GET (may avoid caching)" << endl;
    cout << " --head : use HEAD rather than GET" << endl;
	cout << " --proxy-server : specify a proxy server " << endl;
	cout << " --proxy-port   : specify a proxy port " << endl;
    cout << endl << "Debug Options:" << endl;
    cout << " -f     : force tcping to send at least one byte" << endl;
    cout << endl << "\tIf you don't pass server-port, it defaults to " << kDefaultServerPort << "." << endl;

}


int main(int argc, char* argv[]) {

    // Do we have enough command line arguments?
    if (argc < 2) {
        usage(argc, argv);
        return 1;
    }

    int times_to_ping = 4;
    int offset = 0;  // because I don't feel like writing a whole command line parsing thing, I just want to accept an optional -t.  // well, that got out of hand quickly didn't it? -Future Eli
    float ping_interval = 1;
    int include_timestamp = 0;
    int beep_mode = 0;  // 0 is off, 1 is down, 2 is up, 3 is on change, 4 is constantly
    int ping_timeout = 2000;
    int relookup_interval = -1;
    int auto_exit_on_success = 0;
    int force_send_byte = 0;

    int include_url = 0;
    int use_http = 0;
    int http_cmd = 0;

    int include_jitter = 0;
    int jitter_sample_size = 0;

    int only_changes = 0;

    // for http mode
    char *serverptr;
    char *docptr = NULL;
    char server[2048];
    char document[2048];

    // for --tee
    char logfile[256];
    int use_logfile = 0;

    // preferred IP version
    int ipv = 0;

	// http proxy server and port
	int proxy_port = 3128;
	char proxy_server[2048];
	proxy_server[0] = 0;


    for (int x=0; x < argc; x++) {

        if (!strcmp(argv[x], "/?") || !strcmp(argv[x], "?") || !strcmp(argv[x], "--help") || !strcmp(argv[x], "-help")) {
            usage(argc, argv);
            return 1;
        }

		if (!strcmp(argv[x], "--proxy-port")) {
			proxy_port = atoi(argv[x+1]);
			//cout << "proxyport " << proxy_port << endl;
			offset = x + 1;
		}

		if (!strcmp(argv[x], "--proxy-server")) {
			sprintf(proxy_server, argv[x+1]);
			//cout << "proxyserver " << proxy_server << endl;
			offset = x + 1;
		}

		
        // force IPv4
        if (!strcmp(argv[x], "-4")) {
            ipv = 4;
            offset = x;
        }

        // force IPv6
        if (!strcmp(argv[x], "-6")) {
            ipv = 6;
            offset = x;
        }

        // ping continuously
        if (!strcmp(argv[x], "-t")) {
            times_to_ping = -1;
            offset = x;
            cout << endl << "** Pinging continuously.  Press control-c to stop **" << endl;
        }

        // Number of times to ping
        if (!strcmp(argv[x], "-n")) {
            times_to_ping = atoi(argv[x+1]);
            offset = x+1;
        }

        // exit on first successful ping
        if (!strcmp(argv[x], "-s")) {
            auto_exit_on_success = 1;
            offset = x;
        }

        // tee to a log file
        if (!strcmp(argv[x], "--tee")) {
            strcpy( logfile, static_cast<const char*>(argv[x+1]) );
            offset = x+1;
            use_logfile = 1;
        }

        // http mode
        if (!strcmp(argv[x], "-h")) {
            use_http = 1;
            offset = x;
        }

        // http mode - use get
        if (!strcmp(argv[x], "--get")) {
            use_http = 1; //implied
            http_cmd = HTTP_GET;
            offset = x;
        }

        // http mode - use head
        if (!strcmp(argv[x], "--head")) {
            use_http = 1; //implied
            http_cmd = HTTP_HEAD;
            offset = x;
        }

        // http mode - use post
        if (!strcmp(argv[x], "--post")) {
            use_http = 1; //implied
            http_cmd = HTTP_POST;
            offset = x;
        }

        // include url per line
        if (!strcmp(argv[x], "-u")) {
            include_url = 1;
            offset = x;
        }

        // force send a byte
        if (!strcmp(argv[x], "-f")) {
            force_send_byte = 1;
            offset = x;
        }

        // interval between pings
        if (!strcmp(argv[x], "-i")) {
            ping_interval = atof(argv[x+1]);
            offset = x+1;
        }

        // wait for response
        if (!strcmp(argv[x], "-w")) {
            ping_timeout = 1000 * atof(argv[x+1]);
            offset = x+1;
        }

        // optional datetimestamp output
        if (!strcmp(argv[x], "-d")) {
            include_timestamp = 1;
            offset = x;
        }

        // optional jitter output
        if (!strcmp(argv[x], "-j")) {
            include_jitter = 1;
            offset = x;

            //cout << "offset going in " << offset << endl;

            // obnoxious special casing if they actually specify the default 0
            if (!strcmp(argv[x+1], "0")) {
                //cout << "natural zero" << endl;
                //cout << argv[x+1] << " is " << atoi(argv[x+1]) << "!!" << endl;
                //cout << "then we have " << argv[x+2] << endl;
                jitter_sample_size = 0;
                offset = x+1;
            } else {
                if (atoi(argv[x+1]) == 0) {
                    //cout << argv[x+1] << " is " << atoi(argv[x+1]) << "!!" << endl;
                    offset = x;
                } else {
                    jitter_sample_size = atoi(argv[x+1]);
                    //if (jitter_sample_size < 2) {
                    //	cout << "Jitter sample size smaller than two does not make sense." << endl;
                    //	return(1);
                    //}
                    offset = x+1;
                }
            }
            //			cout << "offset coming out "<< offset << endl;
        }

        // optional hostname re-lookup
        if (!strcmp(argv[x], "-r")) {
            relookup_interval = atoi(argv[x+1]);
            offset = x+1;
        }
		
		 // optional output minimization
        if (!strcmp(argv[x], "-c")) {
            only_changes = 1;
            offset = x;
			cout << endl << "** Only displaying output for state changes. **" << endl;
        }

        // optional beepage
        if (!strcmp (argv[x], "-b")) {
            beep_mode = atoi(argv[x+1]);
            offset = x+1;
            switch (beep_mode) {
            case 0:
                break;
            case 1:
                cout << endl << "** Beeping on \"down\" - (two beeps) **" << endl;
                break;
            case 2:
                cout << endl << "** Beeping on \"up\"  - (one beep) **" << endl;
                break;
            case 3:
                cout << endl << "** Beeping on \"change\" - (one beep up, two beeps down) **" << endl;
                break;
            case 4:
                cout << endl << "** Beeping constantly - (one beep up, two beeps down) **" << endl;
                break;
            }

        }

        // dump version and quit
        if (!strcmp(argv[x], "-v") || !strcmp(argv[x], "--version") ) {
            cout << "tcping.exe 0.23 Apr 02 2014" << endl;
            cout << "compiled: " << __DATE__ << " " << __TIME__ << endl;
            cout << endl;
            cout << "tcping.exe by Eli Fulkerson " << endl;
            cout << "Please see http://www.elifulkerson.com/projects/ for updates. " << endl;
            cout << endl;
            cout << "-s option contributed 14 Apr 2011 by Michael Bray, mbray@presidio.com" << endl;
            return 1;
        }
    }

    // Get host and (optionally) port from the command line

    char* pcHost;
    if (argc >= 2 + offset) {
        pcHost = argv[1 + offset];
    } else {
        cout << "Check the last flag before server-address.  Did you specify a flag and forget its argument?" << endl;
        return 1;
    }

    int nPort = kDefaultServerPort;
    if (argc >= 3 + offset) {
        nPort = atoi(argv[2 + offset]);
    }

    // Do a little sanity checking because we're anal.
    int nNumArgsIgnored = (argc - 3 - offset);
    if (nNumArgsIgnored > 0) {
        cout << nNumArgsIgnored << " extra argument" << (nNumArgsIgnored == 1 ? "" : "s") << " ignored.  FYI." << endl;
    }

    if (use_http == 1) {
        serverptr = strchr(pcHost, ':');
        if (serverptr != NULL) {
            ++serverptr;
            ++serverptr;
            ++serverptr;
        } else {
            serverptr = pcHost;
        }

        docptr = strchr(serverptr, '/');
        if (docptr != NULL) {
            *docptr = '\0';
            ++docptr;

            strcpy( server, static_cast<const char*>(serverptr) );
            strcpy( document, static_cast<const char*>(docptr) );
        } else {
            strcpy( server, static_cast<const char*>(serverptr) );
            document[0] = '\0';
        }

        cout << endl << "** Requesting \"" << document << "\" from " << server << ":" << endl;
        cout << "(for various reasons, kbit/s is an approximation)" << endl;
    }

    SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);

    // Start Winsock up
    WSAData wsaData;
    int nCode;
    if ((nCode = WSAStartup(MAKEWORD(1, 1), &wsaData)) != 0) {
        cout << "WSAStartup() returned error code " << nCode << "." << endl;
        return 255;
    }

    // Call the main example routine.
    int retval = DoWinsock(pcHost, nPort, times_to_ping, ping_interval, include_timestamp, beep_mode, ping_timeout, relookup_interval, auto_exit_on_success, force_send_byte, include_url, use_http, docptr, http_cmd, include_jitter, jitter_sample_size, logfile, use_logfile, ipv, proxy_server, proxy_port, only_changes);

    // Shut Winsock back down and take off.
    WSACleanup();
    return retval;
}

